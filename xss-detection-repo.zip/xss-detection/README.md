# XSS Detection: CNN Features + Cost-Sensitive Ensemble

CSML project, NIT Puducherry. Detects cross-site scripting (XSS) payloads using CNN-extracted features fed into a cost-sensitive ensemble (Random Forest, XGBoost, SVM). The goal is to reduce false negatives (missed attacks) compared with a paper-style CNN-SVM baseline.

## Pipeline
1. Payload normalisation (URL/HTML decoding, unicode normalisation) and dataset loading
2. Text-to-image conversion of payloads
3. CNN feature extractor
4. Feature selection + RF / XGBoost / SVM classifiers
5. Cost-sensitive ensemble with tuned decision threshold
6. Evaluation: baseline vs. proposed, ablation, obfuscation tests (5 known + 3 held-out), optional multi-seed runs
7. Optional Gradio prototype UI

## Dataset
Kaggle XSS dataset (not included in this repo). Download it and place the CSV in `data/`, or on Kaggle add it via **Add Input**.
The notebook currently searches `/kaggle/input`; to run locally change `DATA_PATH` in the "Load data" cell to your CSV path.

## Running
```bash
pip install -r requirements.txt
jupyter notebook xss_detection.ipynb
```
Run cells top to bottom. The main run saves tables, plots and models to `./outputs`. A GPU is recommended (about 5-10 min on a Kaggle GPU).

## Authors
Add team members here.
